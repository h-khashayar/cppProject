#include "SuperMarket.hpp"

using namespace std;

void printBillReportMenu(){
    cout<<"\t\t\tAll Items\n";
    cout<<"\t\t\t=========================\n";
    return;
}

void printBillEditorMenu(){
    cout<<"\t\t\tSuper Market Billing\n";
    cout<<"\t\t\t=========================\n";
    cout<<"\t\t1.Add Item Details\n";
    cout<<"\t\t2.Edit Item Details\n";
    cout<<"\t\t3.Delete Item Details\n";
    cout<<"\t\t4.Back to Main Menu\n";
    return;
}

void printItemDetailsMenu(){
    cout<<"\t\t\tPrinting Item Details\n";
    cout<<"\t\t\t=========================\n";
    cout<<"\t\tItem Id: ";
    return;
}

void printExitMenu(){
    cout<<"\t\t\tGoodbye\n";
    cout<<"\t\t\t=========================\n";
    return;
}

SuperMarket::SuperMarket(){
    currentMenu = 0;
}

void SuperMarket::printMenu(){
    switch(currentMenu){
        case 0:
            printMainMenu();
            break;
        case 1:
            printBillReportMenu();
            break;
        case 2:
            printBillEditorMenu();
            break;
        case 3:
            printItemDetailsMenu();
            break;
        case 4:
            printExitMenu();
            break;
    }
    cout<<"Input Command: ";
}

void SuperMarket::printAllBills(){
    for (int i=0; i < products.size() ; i++){
        products[i].printDescribtion();
    }
}

void SuperMarket::handle_input(int x){
    if (currentMenu == 0){
        switch(x){
            case 1:
                printBillReportMenu();
                printAllBills();
                break;
            case 2:
                currentMenu = 2;
                break;
            case 3:
                currentMenu = 3;
                break;
            case 4:
                printExitMenu();
                exit(0);
                break;
            default:
                cout<<"Invalid input!\n";
        }
    }else if (currentMenu == 2){
        int no;
        string manDate;
        string price;
        string type;
        string name;
        Merch temp;
        int i = 0;
        int index = -1;
        switch(x){
            case 1:
                
                cout<<"item number: ";
                cin>>no;
                cout<<"name: ";
                cin>>name;
                cout<<"manufacture date: ";
                cin>>manDate;
                cout<<"price: ";
                cin>>price;
                cout<<"type: ";
                cin>>type;
                temp = Merch(name, no, manDate, price, type);
                products.push_back(temp);
                cin.clear();
                break;
            case 2:
                cout<<"item number: ";
                cin>>no;
                for (i=0; i < products.size(); i++){
                    if (products[i].id == no){
                        index = i;
                        break;
                    }
                }
                if (index == -1){
                    cout<<"item was not found. try again please\n";
                    return;
                }
                cout<<"item found. enter details:\n";
                cout<<"name: ";
                cin>>name;
                cout<<"manufacture date: ";
                cin>>manDate;
                cout<<"price: ";
                cin>>price;
                cout<<"type: ";
                cin>>type;
                products[index].editDetails(name, manDate, price, type);
                cin.clear();
                break;
            case 3:
            {
                cout<<"item number: ";
                cin>>no;
                for (i=0; i < products.size(); i++){
                    if (products[i].id == no){
                        index = i;
                        break;
                    }
                }
                if (index == -1){
                    cout<<"item was not found. try again please\n";
                    return;
                }
                cout<<"deleting item... \n";
                products.erase(products.begin()+index);
                cout<<"done.\n";
                cin.clear();
                break;
            }
            case 4:
                currentMenu = 0;
                break;
            default:
                cout<<"what?\n";
                cout<<"Invalid input!\n";
        }
    }else{
        for (int i=0; i < products.size(); i++){
            if (products[i].id == x){
                products[i].printDescribtion();
                currentMenu = 0;
                return;
            }
        }
        cout<<"Item did not have description and/or was not found\n";
        currentMenu = 0;
    }
    return;
}

int handleInput (string input, SuperMarket& khashisMarket){
    vector<string> duppedInput = getRawDuppedCommandLine(input);
    if (duppedInput.size() != 0){
        if (duppedInput.size() != 1){
            cout<<"Invalid input\n";
            return 0;
        }
        try{
            int x = stoi(duppedInput[0]);
            khashisMarket.handle_input(x);
            return 1;
        }catch(exception& any){
            cout<<"exception"<<endl;
            cout<<"Invalid input"<<endl;
            return 0;
        }
    }
    return 0;
}

void printMainMenu(){
    cout<<"\t\t\tSuper Market Billing\n";
    cout<<"\t\t\t=========================\n";
    cout<<"\t\t1.Bill Report\n";
    cout<<"\t\t2.Add/remove/edit Item\n";
    cout<<"\t\t3.Show Item Details\n";
    cout<<"\t\t4.Exit\n";
    return;
}

