#ifndef __INTERFACE_HPP__
#define __INTERFACE_HPP__

#include <string>
#include <vector>
#include "CommandLineParsing.hpp"
#include "User.hpp"
#include "Merch.hpp"
#include "Exceptions.hpp"
#include "Structs.hpp"
#include "Buyer.hpp"
#include "Seller.hpp"
#include <unordered_map>
#include "DataParsing.hpp"
#include <stdlib.h>
#include <time.h>

#define ADMINID 0
#define YES 1
#define NO 0
#define DISCOUNTWORDS 5
class SuperMarket{
public:
	SuperMarket();
    void printMenu();
    void handle_input(int x);
    void printAllBills();
private:
    int currentMenu;
    std::vector<Merch> products;
};

void printMainMenu();

void printBillReportMenu();

void printBillEditorMenu();

void printItemDetailsMenu();

void printExitMenu();

int handleInput (string input, SuperMarket& khashisMarket);

#endif