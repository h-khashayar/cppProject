#include "SuperMarket.hpp"

using namespace std;

int main(){
    srand (time(NULL));
    SuperMarket khashisMarket;
    string input;
    khashisMarket.printMenu();
    while (getline(cin, input)){
        int x = handleInput(input, khashisMarket);
        if (x)
            khashisMarket.printMenu();
    }
}