#ifndef _Merch_HH_
#define _Merch_HH_

#include <iostream>
#include <vector>
#include <string>
#include "Structs.hpp"

using namespace std;

class Merch{
public:
    Merch(){}
    Merch(string nam, int Id, string manuDate, string wPrice, string wType){name = nam; id = Id; manDate = manuDate; price = wPrice; type = wType;}
    void editDetails(string nam, string manuDate, string wPrice, string wType){name = nam; manDate = manuDate; price = wPrice; type = wType;}
    void printOneLineDes(){
        cout<<id<<" | "<<name<<endl;
    }
    void printDescribtion(){
        cout<<"Item Id: "<< id<<endl;
        cout<<"Item Name: "<< name<<endl;
        cout<<"Price: "<< price<<endl;
        cout<<"Type: "<< type<<endl;
        cout<<"manufacture Date: "<<manDate<<endl;
    }
    int id;
protected:
    string manDate;
    string price;
    string type;
    std::string name;
};

#endif